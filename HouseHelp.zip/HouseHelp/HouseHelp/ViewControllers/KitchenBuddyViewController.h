//
//  KitchenTipsViewController.h
//  HouseHelp
//
//  Created by Breakstuff on 9/24/13.
//  Copyright (c) 2013 FastData. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KitchenBuddyView.h"
@interface KitchenBuddyViewController : UIViewController <KitchenBuddyViewDelegate>
- (id)init;
@end
