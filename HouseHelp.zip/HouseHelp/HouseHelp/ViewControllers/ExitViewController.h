//
//  ExitViewController.h
//  HouseHelp
//
//  Created by Breakstuff on 9/29/13.
//  Copyright (c) 2013 FastData. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KitchenView.h"
@interface ExitViewController : UIViewController
- (id)init;
@property id <KitchenViewDelegate> delegate;
@end
