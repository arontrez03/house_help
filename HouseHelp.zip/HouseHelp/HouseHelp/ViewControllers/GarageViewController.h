//
//  GarageViewController.h
//  HouseHelp
//
//  Created by Breakstuff on 10/7/13.
//  Copyright (c) 2013 FastData. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GarageView.h"
@interface GarageViewController : UIViewController
{
    UITabBarItem* uitbi;
}
- (id)init;
- (void)loadView;
@end
