//
//  DiningViewDelegate.h
//  HouseHelp
//
//  Created by macuser on 10/7/13.
//  Copyright (c) 2013 FastData. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol DiningroomViewDelegate <NSObject>
- (void)didTouchHome;
@end
