//
//  RecipesViewDelegate.h
//  HouseHelp
//
//  Created by Breakstuff on 9/29/13.
//  Copyright (c) 2013 FastData. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol RecipesViewDelegate <NSObject>
- (void)didTouchGoBack;
@end
