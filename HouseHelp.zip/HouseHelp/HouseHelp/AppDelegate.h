//
//  AppDelegate.h
//  HouseHelp
//
//  Created by Breakstuff on 9/20/13.
//  Copyright (c) 2013 FastData. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HouseHelpMainViewController.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
