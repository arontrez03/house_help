//
//  RestroomExitViewController.h
//  HouseHelp
//
//  Created by macuser on 10/7/13.
//  Copyright (c) 2013 FastData. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RestroomViewDelegate.h"
@interface RestroomExitViewController : UIViewController
- (id)init;
@property id <RestroomViewDelegate> delegate;
@end
