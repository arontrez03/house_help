//
//  LivingroomExitViewController.h
//  HouseHelp
//
//  Created by macuser on 10/7/13.
//  Copyright (c) 2013 FastData. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LivingroomView.h"
@interface LivingroomExitViewController : UIViewController
- (id)init;
@property id <LivingroomViewDelegate> delegate;
@end